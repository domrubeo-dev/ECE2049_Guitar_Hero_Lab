#include <stdint.h>
#include <stdio.h>
#include "game_clock.h"
#include "stm32h533xx.h"
#include "stm32h5xx_hal_tim.h"

static volatile uint32_t time_ms;

void configGameClock(void){
    RCC->APB1LENR |= RCC_APB1LENR_TIM3EN;
    TIM3->PSC = 31;
    TIM3->ARR = 999;
    TIM3->EGR = TIM3_EGR_UG;
    TIM3->DIER |= TIM3_DIER_UIE;
    NVIC_EnableIRQ(TIM3_IRQn);
    TIM3->CR1 |= TIM3_CR1_CEN;
}

void TIM3_IRQHandler(void){
    if (TIM3->SR & TIM_SR_UIF) {
        TIM3->SR = ~TIM_SR_UIF;
        time_ms++;
    }
}

uint32_t getTime(void){
    return time_ms;
}