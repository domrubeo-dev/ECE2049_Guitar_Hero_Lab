#include <stdio.h>
#include <stdint.h>
#include "fsm.h"
#include "Adafruit_TFTShield18_API.h"
#include "Adafruit_TFTShield18_Macros.h"

static State current = WELCOME;
uint32_t reset_btn;

void run_fsm(void){
    switch(current){
        case WELCOME:
        reset_btn = TFTShield18_readButtons();   
        if(~reset_btn & TFTSHIELD_BUTTON_IN){
            current = COUNTDOWN;
        }
            break;
        case COUNTDOWN:
            if(~reset_btn & TFTSHIELD_BUTTON_IN){
                current = WELCOME;
            }   
            break;
        case GAMEPLAY:
            if(~reset_btn & TFTSHIELD_BUTTON_IN){
                current = WELCOME;
            }
            break;
        case WIN:
            if(~reset_btn & TFTSHIELD_BUTTON_IN){
                current = WELCOME;
            }
            break;
        case LOSE:
            if(~reset_btn & TFTSHIELD_BUTTON_IN){
                current = WELCOME;
            }
            break;
    }
}