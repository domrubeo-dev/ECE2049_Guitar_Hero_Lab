#include <stdio.h>
#include <stdint.h> 
#include "play_game.h"
#include "game_clock.h"
#include "button.h"

enum{
    X = 0b00000000,
    A = 0b00000001,
    B = 0b00000010,
    C = 0b00000100,
    E = 0b00000011
};
SongNote song[] = {{NOTE_A, 250, A}, {NOTE_C, 250, C}};
uint32_t note_start;
uint32_t hold_start;
extern Buzzer buzzer1;
uint8_t button;

int score;
int note;
int finished;
static int timer_btn;
static int note_scored;

void startGame(void){
    score = 0;
    note = 0;
    finished = 0;
    timer_btn = 0;
    note_scored = 0;
    note_start = getTime();
    buzzerSetNote(&buzzer1, song[note].pitch, 1);
    buzzerEnable(&buzzer1);
}

void updateGame(void){
    if(finished){
        return;
    }
    
    if ((getTime() - note_start ) >= song[note].duration_ms){
        buzzerDisable(&buzzer1);
        note_start = getTime();
        note++;
        if (note >= sizeof(song)/sizeof(song[0])){
            finished = 1;
            return;
        }
        timer_btn = 0;
        note_scored = 0;

        buzzerSetNote(&buzzer1, song[note].pitch, 1);
        buzzerEnable(&buzzer1);
    }
    
    button = readInput();
    
    if(button == X || button != song[note].name){
        timer_btn = 0;
    }
    
    if(button > X && song[note].name == button){
        if(!timer_btn){
            hold_start = getTime();
            timer_btn =1;
        }
        if(!note_scored && (getTime() - hold_start >= (song[note].duration_ms - 50))){
            score++;
            note_scored = 1;
        }
    }
}

int gameFinished(){
    return finished;
}