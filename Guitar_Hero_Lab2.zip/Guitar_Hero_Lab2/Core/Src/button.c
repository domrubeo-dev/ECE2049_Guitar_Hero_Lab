#include <stdio.h>
#include <stdint.h>
#include "button.h"

void configButtons(void){
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;

    //Red Button Config
    BTNR_PORT->MODER &= ~BTNR_MODER;
    
    BTNR_PORT->PUPDR &= ~BTNR_PUPDR;
    BTNR_PORT->PUPDR |= BTNR_PUPDR_PD;

    //Blue Button Config
    BTNB_PORT->MODER &= ~BTNB_MODER;
    
    BTNB_PORT->PUPDR &= ~BTNB_PUPDR;
    BTNB_PORT->PUPDR |= BTNB_PUPDR_PD;

    //Yellow Button Config
    BTNY_PORT->MODER &= ~BTNY_MODER;
    
    BTNY_PORT->PUPDR &= ~BTNY_PUPDR;
    BTNY_PORT->PUPDR |= BTNY_PUPDR_PD;
}

uint8_t readInput(void){
    uint8_t input = 0;
    if(BTNR_PORT->IDR & BTNR_BIT){
        input = 0b00000001;
    }
    if(BTNB_PORT->IDR & BTNB_BIT){
        input = 0b00000010;
    }
    if(BTNY_PORT->IDR & BTNY_BIT){
        input = 0b00000100;
    }
    if ((BTNR_PORT->IDR & BTNR_BIT)&&(BTNB_PORT->IDR & BTNB_BIT)){
        input = 0b00000011;
    }
    if ((BTNR_PORT->IDR & BTNR_BIT)&&(BTNY_PORT->IDR & BTNY_BIT)){
        input = 0b00000101;
    }
    if ((BTNY_PORT->IDR & BTNY_BIT)&&(BTNB_PORT->IDR & BTNB_BIT)){
        input = 0b00000110;
    }
    if ((BTNR_PORT->IDR & BTNR_BIT)&&(BTNB_PORT->IDR & BTNB_BIT)&&(BTNY_PORT->IDR & BTNY_BIT)){
        input = 0b00000111;
    }
    return input;
}