#ifndef FSM_H
#define FSM_H

#include <stdio.h>

typedef enum {
    WELCOME,
    COUNTDOWN,
    GAMEPLAY,
    WIN,
    LOSE,
} State;

void run_fsm(void);

#endif