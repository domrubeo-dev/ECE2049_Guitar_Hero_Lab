#ifndef BTN_H
#define BTN_H
#include "stm32h533xx.h"
#include <stdint.h>

//Red BTN
#define BTNR_PORT GPIOC
#define BTNR_MODER GPIO_MODER_MODE13
#define BTNR_BIT GPIO_IDR_ID13
#define BTNR_PUPDR GPIO_PUPDR_PUPD13
#define BTNR_PUPDR_PD GPIO_PUPDR_PUPD13_1

//Blue BTN
#define BTNB_PORT GPIOC
#define BTNB_MODER GPIO_MODER_MODE14
#define BTNB_BIT GPIO_IDR_ID14
#define BTNB_PUPDR GPIO_PUPDR_PUPD14
#define BTNB_PUPDR_PD GPIO_PUPDR_PUPD14_1

//Yellow BTN
#define BTNY_PORT GPIOC
#define BTNY_MODER GPIO_MODER_MODE15
#define BTNY_BIT GPIO_IDR_ID15
#define BTNY_PUPDR GPIO_PUPDR_PUPD15
#define BTNY_PUPDR_PD GPIO_PUPDR_PUPD15_1

void configButtons(void);
uint8_t readInput(void);

#endif
