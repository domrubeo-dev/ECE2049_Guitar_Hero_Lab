#include <stdint.h>
#include <stdio.h>

#ifndef GAME_CLOCK

#define GAME_CLOCK

void configGameClock(void);
void TIM3_IRQHandler(void);
uint32_t getTime(void);

#endif