#ifndef PLAY_GAME_H
#define  PLAY_GAME_H

#include <stdint.h>
#include <stdio.h>
#include "buzzer.h"

typedef struct  {
    Note pitch;
    uint16_t duration_ms;
    uint8_t name;
}SongNote;

void startGame(void);
void updateGame(void);
int gameFinished(void);

#endif


